# iOS 26 Launcher (Android Native)

Dự án launcher Android viết bằng Kotlin + Jetpack Compose. Đây là ứng dụng Android native, không phải website/WebView.

## Đã triển khai trong bản khởi đầu

- Activity có intent filter `HOME` + `DEFAULT`, có thể chọn làm launcher mặc định.
- Tự truy vấn danh sách ứng dụng có thể mở bằng Android PackageManager; mở app thật khi nhấn icon.
- Lưới biểu tượng ứng dụng, dock 4 ứng dụng, thư viện ứng dụng và tìm kiếm.
- Nhấn giữ icon để mở app hoặc xem trang thông tin ứng dụng Android.
- Dynamic Island mô phỏng có animation co/giãn, hiển thị giờ và mức pin.
- Control Center dạng kính mờ: mở trang Wi-Fi/Bluetooth/chế độ máy bay/cài đặt âm thanh; đèn pin có điều khiển thật sau khi người dùng cấp quyền Camera; điều chỉnh âm lượng media và độ sáng cửa sổ launcher.
- Notification Center đọc thông báo thật sau khi người dùng chủ động bật Notification Access trong Cài đặt Android. Nhấn thẻ thử mở hành động thông báo gốc.
- Cài đặt lưu trạng thái Dynamic Island, animation và kích thước icon bằng SharedPreferences.
- Có thể gửi yêu cầu Android để đặt launcher làm mặc định.
- Có Input Method Service bàn phím QWERTY phong cách iOS cơ bản. Người dùng phải tự bật/chọn bàn phím trong cài đặt Android.

## Giới hạn cần biết

- Đây không phải iOS và không thay thế System UI của Android. Status bar, màn hình khóa, quyền Wi-Fi/Bluetooth, dữ liệu di động, điều khiển cuộc gọi và nhiều hành vi hệ thống vẫn thuộc Android.
- Control Center dùng trang Cài đặt Android cho các công tắc mà ứng dụng bên thứ ba không được phép thay đổi trực tiếp.
- Bản này chưa có host widget Android, kéo-thả/sắp xếp icon, thư mục tùy chỉnh, bộ chọn hình nền riêng, mô phỏng các ứng dụng Phone/Messages/Photos độc lập, hay hiệu ứng mở/đóng app ở cấp hệ thống. App thật vẫn mở bằng Android.
- Dynamic Island là thành phần giao diện trong launcher, không phải overlay toàn hệ thống nên không xuất hiện khi ở trong ứng dụng khác.
- Bàn phím là IME cơ bản; không có dự đoán từ, kiểm tra chính tả hay bộ gõ tiếng Việt Telex/VNI.
- Không cam kết 60/90/120 FPS trên mọi thiết bị; hiệu năng phụ thuộc phần cứng và phiên bản Android.

## Yêu cầu build

- Android Studio với Android SDK Platform 35.
- JDK 17.
- Kết nối Internet trong lần build đầu để tải Gradle và thư viện Maven.

## Build APK debug

### Windows

Mở thư mục dự án trong Android Studio rồi chọn **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Hoặc mở CMD/PowerShell tại thư mục này và chạy:

```bat
gradlew.bat :app:assembleDebug
```

### macOS / Linux

```bash
./gradlew :app:assembleDebug
```

APK đầu ra:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Có thể dùng `build-apk.sh` trên macOS/Linux.

## Cài đặt và sử dụng

1. Build APK và cài lên Android (cho phép cài ứng dụng từ nguồn bạn dùng nếu Android hỏi).
2. Mở **iOS 26 Launcher**.
3. Trong giao diện launcher, mở **Cài đặt** > **Đặt làm Launcher mặc định**.
4. Chọn **iOS 26 Launcher** trong hộp thoại Android.
5. Muốn dùng bàn phím: vào **Cài đặt** > **Bật bàn phím kiểu iOS**, bật `iOS Style Keyboard`, rồi chọn nó làm bàn phím hiện tại.
6. Muốn xem thông báo trong bảng riêng: mở **Thông báo** và bấm cấp quyền truy cập thông báo. Chỉ bật nếu bạn đồng ý cho ứng dụng đọc nội dung thông báo trên thiết bị.

## Cấu trúc chính

- `app/src/main/java/.../MainActivity.kt`: Activity launcher.
- `InstalledApp.kt`: truy vấn và mở ứng dụng Android.
- `ui/LauncherApp.kt`: giao diện Home, Dock, App Library, Control Center, Notification Center, Settings và Dynamic Island.
- `NotificationAccessService.kt`: listener thông báo có quyền cấp thủ công.
- `keyboard/IosKeyboardService.kt`: bàn phím IME phong cách iOS.
