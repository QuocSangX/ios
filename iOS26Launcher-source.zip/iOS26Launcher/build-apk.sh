#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
./gradlew :app:assembleDebug
printf '\nAPK created at: %s\n' "$(pwd)/app/build/outputs/apk/debug/app-debug.apk"
