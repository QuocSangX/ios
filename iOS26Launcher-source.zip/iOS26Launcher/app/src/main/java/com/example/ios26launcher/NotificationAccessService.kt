package com.example.ios26launcher

import android.app.Notification
import android.app.PendingIntent
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.mutableStateListOf

 data class LauncherNotification(
    val key: String,
    val appName: String,
    val title: String,
    val message: String,
    val postedAt: Long,
    val contentIntent: PendingIntent?
)

/** Notifications are read only after the user explicitly enables Notification Access in Android Settings. */
object NotificationCenter {
    val items = mutableStateListOf<LauncherNotification>()
}

class NotificationAccessService : NotificationListenerService() {
    private val mainHandler = Handler(Looper.getMainLooper())

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val notification = sbn.notification ?: return
        if ((notification.flags and Notification.FLAG_ONGOING_EVENT) != 0) return
        val extras = notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val message = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString().orEmpty()
        if (title.isBlank() && message.isBlank()) return

        val appName = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (_: Exception) {
            sbn.packageName
        }

        val item = LauncherNotification(
            key = sbn.key,
            appName = appName,
            title = title,
            message = message,
            postedAt = sbn.postTime,
            contentIntent = notification.contentIntent
        )
        mainHandler.post {
            NotificationCenter.items.removeAll { it.key == item.key }
            NotificationCenter.items.add(0, item)
            while (NotificationCenter.items.size > 30) NotificationCenter.items.removeAt(NotificationCenter.items.lastIndex)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        mainHandler.post { NotificationCenter.items.removeAll { it.key == sbn.key } }
    }
}
