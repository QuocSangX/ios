package com.example.ios26launcher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Build

/** A launchable app discovered through Android's public package visibility APIs. */
data class InstalledApp(
    val label: String,
    val packageName: String,
    val className: String,
    val icon: Drawable
)

@Suppress("DEPRECATION")
fun loadInstalledApps(context: Context): List<InstalledApp> {
    val pm = context.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val resolved = if (Build.VERSION.SDK_INT >= 33) {
        pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
    } else {
        pm.queryIntentActivities(intent, 0)
    }

    return resolved.mapNotNull { info ->
        val activity = info.activityInfo ?: return@mapNotNull null
        try {
            InstalledApp(
                label = info.loadLabel(pm)?.toString()?.ifBlank { activity.packageName } ?: activity.packageName,
                packageName = activity.packageName,
                className = activity.name,
                icon = info.loadIcon(pm)
            )
        } catch (_: Exception) {
            null
        }
    }.distinctBy { it.packageName }
        .sortedBy { it.label.lowercase() }
}

fun launchInstalledApp(context: Context, app: InstalledApp) {
    val launchIntent = context.packageManager.getLaunchIntentForPackage(app.packageName)
        ?: Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setClassName(app.packageName, app.className)
    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        context.startActivity(launchIntent)
    } catch (_: Exception) {
        // The app may have been removed or disabled between listing and tapping.
    }
}
