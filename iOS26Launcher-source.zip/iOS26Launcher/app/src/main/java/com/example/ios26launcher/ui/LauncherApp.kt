package com.example.ios26launcher.ui

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.Brightness6
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import com.example.ios26launcher.InstalledApp
import com.example.ios26launcher.LauncherNotification
import com.example.ios26launcher.NotificationCenter
import com.example.ios26launcher.launchInstalledApp
import com.example.ios26launcher.loadInstalledApps
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Ink = Color(0xFF172033)
private val Muted = Color(0xFF667085)
private val Blue = Color(0xFF087CFA)
private val Glass = Color(0xCCFFFFFF)

private enum class LauncherPanel { NONE, LIBRARY, SEARCH, CONTROL, NOTIFICATIONS, SETTINGS }

@Composable
fun LauncherApp() {
    val context = LocalContext.current
    val preferences = remember { context.getSharedPreferences("ios26_launcher", Context.MODE_PRIVATE) }
    var installedApps by remember { mutableStateOf(emptyList<InstalledApp>()) }
    var refreshKey by remember { mutableStateOf(0) }
    var panel by rememberSaveable { mutableStateOf(LauncherPanel.NONE) }
    var query by rememberSaveable { mutableStateOf("") }
    var expandedIsland by rememberSaveable { mutableStateOf(false) }
    var showIsland by remember { mutableStateOf(preferences.getBoolean("dynamic_island", true)) }
    var animationsEnabled by remember { mutableStateOf(preferences.getBoolean("animations", true)) }
    var iconSize by remember { mutableFloatStateOf(preferences.getFloat("icon_size", 1f)) }
    var torchOn by remember { mutableStateOf(false) }
    var currentTime by remember { mutableStateOf(nowTime()) }

    LaunchedEffect(refreshKey) {
        installedApps = withContext(Dispatchers.IO) { loadInstalledApps(context) }
    }
    LaunchedEffect(Unit) {
        while (true) {
            currentTime = nowTime()
            delay(1_000)
        }
    }

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) torchOn = setTorch(context, true)
    }

    val battery = remember {
        val intent = context.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        if (level >= 0 && scale > 0) (level * 100 / scale) else 100
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(Color(0xFF9EC8F7), Color(0xFFC8DDF8), Color(0xFFE9EAF5), Color(0xFFB6CBEA))
                )
            )
    ) {
        // Soft decorative light fields create the frosted-glass wallpaper impression.
        Box(Modifier.align(Alignment.TopEnd).padding(top = 110.dp, end = 18.dp).size(190.dp).background(Color.White.copy(alpha = .18f), CircleShape))
        Box(Modifier.align(Alignment.BottomStart).padding(bottom = 130.dp, start = 12.dp).size(230.dp).background(Color(0xFF6D9EE4).copy(alpha = .13f), CircleShape))

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 6.dp)
                .padding(bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 8.dp)
        ) {
            if (showIsland) {
                DynamicIsland(
                    expanded = expandedIsland,
                    battery = battery,
                    time = currentTime,
                    onClick = { expandedIsland = !expandedIsland },
                    animationsEnabled = animationsEnabled
                )
            } else {
                Spacer(Modifier.height(8.dp))
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 12.dp),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(currentTime, fontSize = 49.sp, fontWeight = FontWeight.Light, color = Ink, letterSpacing = (-1.5).sp)
                    Text(todayDate(), fontSize = 14.sp, color = Ink.copy(alpha = .72f), fontWeight = FontWeight.Medium)
                }
                Surface(color = Color.White.copy(alpha = .45f), shape = RoundedCornerShape(18.dp)) {
                    Row(Modifier.padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.BatteryFull, null, tint = Ink, modifier = Modifier.size(17.dp))
                        Text("$battery%", color = Ink, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(start = 22.dp, end = 18.dp, top = 4.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Ứng dụng", color = Ink, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { panel = LauncherPanel.NOTIFICATIONS }) {
                        Icon(Icons.Filled.Notifications, "Thông báo", tint = Ink)
                    }
                    IconButton(onClick = { panel = LauncherPanel.SEARCH; query = "" }) {
                        Icon(Icons.Filled.Search, "Tìm kiếm", tint = Ink)
                    }
                }
            }

            val dockApps = remember(installedApps) { pickDockApps(installedApps) }
            val homeApps = remember(installedApps, dockApps) {
                installedApps.filterNot { app -> dockApps.any { it.packageName == app.packageName } }.take(20)
            }
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(start = 13.dp, end = 13.dp, top = 6.dp, bottom = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                items(homeApps, key = { it.packageName }) { app ->
                    AppIconTile(app = app, sizeScale = iconSize, onLaunch = { launchInstalledApp(context, app) })
                }
            }

            Surface(
                modifier = Modifier.padding(horizontal = 17.dp).fillMaxWidth(),
                color = Color.White.copy(alpha = .42f),
                shape = RoundedCornerShape(29.dp),
                shadowElevation = 9.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    dockApps.take(4).forEach { app ->
                        AppIconTile(app = app, sizeScale = iconSize, compact = true, onLaunch = { launchInstalledApp(context, app) })
                    }
                    if (dockApps.isEmpty()) {
                        Text("Chưa tìm thấy ứng dụng", color = Muted, fontSize = 12.sp)
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 7.dp, bottom = 2.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                BottomAction("Thư viện", "▦") { panel = LauncherPanel.LIBRARY }
                BottomAction("Control", "◉") { panel = LauncherPanel.CONTROL }
                BottomAction("Cài đặt", "⚙") { panel = LauncherPanel.SETTINGS }
            }
        }

        when (panel) {
            LauncherPanel.LIBRARY -> AppLibraryPanel(installedApps, onClose = { panel = LauncherPanel.NONE }, onLaunch = { launchInstalledApp(context, it) })
            LauncherPanel.SEARCH -> SearchPanel(installedApps, query, onQuery = { query = it }, onClose = { panel = LauncherPanel.NONE }, onLaunch = {
                panel = LauncherPanel.NONE
                launchInstalledApp(context, it)
            })
            LauncherPanel.CONTROL -> ControlCenterPanel(
                torchOn = torchOn,
                onTorch = {
                    if (torchOn) {
                        setTorch(context, false)
                        torchOn = false
                    } else if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        torchOn = setTorch(context, true)
                    } else cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                },
                onClose = { panel = LauncherPanel.NONE },
                onNotifications = { panel = LauncherPanel.NOTIFICATIONS }
            )
            LauncherPanel.NOTIFICATIONS -> NotificationPanel(onClose = { panel = LauncherPanel.NONE })
            LauncherPanel.SETTINGS -> SettingsPanel(
                context = context,
                showIsland = showIsland,
                animationsEnabled = animationsEnabled,
                iconSize = iconSize,
                onIsland = {
                    showIsland = it
                    preferences.edit().putBoolean("dynamic_island", it).apply()
                },
                onAnimations = {
                    animationsEnabled = it
                    preferences.edit().putBoolean("animations", it).apply()
                },
                onIconSize = {
                    iconSize = it
                    preferences.edit().putFloat("icon_size", it).apply()
                },
                onRefresh = { refreshKey++ },
                onClose = { panel = LauncherPanel.NONE }
            )
            LauncherPanel.NONE -> Unit
        }
    }
}

@Composable
private fun DynamicIsland(
    expanded: Boolean,
    battery: Int,
    time: String,
    onClick: () -> Unit,
    animationsEnabled: Boolean
) {
    val shape = RoundedCornerShape(30.dp)
    Box(Modifier.fillMaxWidth().padding(top = 1.dp), contentAlignment = Alignment.TopCenter) {
        Surface(
            modifier = Modifier
                .width(if (expanded) 320.dp else 132.dp)
                .height(if (expanded) 93.dp else 38.dp)
                .shadow(8.dp, shape)
                .animateContentSize(if (animationsEnabled) spring(dampingRatio = .72f, stiffness = Spring.StiffnessMediumLow) else spring(stiffness = Spring.StiffnessHigh)),
            color = Color.Black,
            shape = shape,
            onClick = onClick
        ) {
            if (expanded) {
                Column(Modifier.padding(horizontal = 17.dp, vertical = 12.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("●  iOS 26 Launcher", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text("$battery%", color = Color.White.copy(alpha = .85f), fontSize = 12.sp)
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Màn hình chính", color = Color.White.copy(alpha = .75f), fontSize = 12.sp)
                        Text(time, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                Row(Modifier.fillMaxSize().padding(horizontal = 15.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Box(Modifier.size(7.dp).background(Color(0xFF35D07F), CircleShape))
                    Box(Modifier.width(29.dp).height(5.dp).background(Color(0xFF282828), RoundedCornerShape(8.dp)))
                }
            }
        }
    }
}

@Composable
private fun AppIconTile(app: InstalledApp, sizeScale: Float, compact: Boolean = false, onLaunch: () -> Unit) {
    val context = LocalContext.current
    val bitmap = remember(app.packageName) {
        runCatching { app.icon.toBitmap(128, 128).asImageBitmap() }.getOrNull()
    }
    var menuOpen by remember { mutableStateOf(false) }
    val iconSize = (if (compact) 53 else 55) * sizeScale
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(onClick = onLaunch, onLongClick = { menuOpen = true })
            .padding(vertical = if (compact) 0.dp else 3.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (bitmap != null) {
            Image(bitmap = bitmap, contentDescription = app.label, modifier = Modifier.size(iconSize.dp).clip(RoundedCornerShape(14.dp)))
        } else {
            Box(Modifier.size(iconSize.dp).background(Color.White, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Text(app.label.take(1), color = Ink, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            }
        }
        if (!compact) {
            Text(
                text = app.label,
                color = Color(0xFF152035),
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp, horizontal = 1.dp)
            )
        }
    }
    androidx.compose.material3.DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
        androidx.compose.material3.DropdownMenuItem(text = { Text("Mở ứng dụng") }, onClick = { menuOpen = false; onLaunch() })
        androidx.compose.material3.DropdownMenuItem(text = { Text("Thông tin ứng dụng") }, onClick = {
            menuOpen = false
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}"))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            runCatching { context.startActivity(intent) }
        })
    }
}

@Composable
private fun BottomAction(label: String, symbol: String, onClick: () -> Unit) {
    androidx.compose.material3.TextButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 3.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(symbol, color = Ink, fontSize = 17.sp)
            Text("  $label", color = Ink, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun AppLibraryPanel(apps: List<InstalledApp>, onClose: () -> Unit, onLaunch: (InstalledApp) -> Unit) {
    PanelBackground(onClose = onClose, title = "Thư viện ứng dụng") {
        LazyVerticalGrid(columns = GridCells.Fixed(4), contentPadding = PaddingValues(bottom = 32.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            items(apps, key = { it.packageName }) { app -> AppIconTile(app, 1f, onLaunch = { onLaunch(app) }) }
        }
    }
}

@Composable
private fun SearchPanel(
    apps: List<InstalledApp>,
    query: String,
    onQuery: (String) -> Unit,
    onClose: () -> Unit,
    onLaunch: (InstalledApp) -> Unit
) {
    val results = remember(apps, query) { apps.filter { it.label.contains(query, ignoreCase = true) }.take(40) }
    PanelBackground(onClose = onClose, title = "Tìm kiếm") {
        TextField(
            value = query,
            onValueChange = onQuery,
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("Tìm ứng dụng") },
            leadingIcon = { Icon(Icons.Filled.Search, null) },
            shape = RoundedCornerShape(18.dp),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Color.White,
                unfocusedContainerColor = Color.White,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent
            )
        )
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(4), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            items(results, key = { it.packageName }) { app -> AppIconTile(app, 1f, onLaunch = { onLaunch(app) }) }
        }
    }
}

@Composable
private fun ControlCenterPanel(
    torchOn: Boolean,
    onTorch: () -> Unit,
    onClose: () -> Unit,
    onNotifications: () -> Unit
) {
    val context = LocalContext.current
    var volume by remember { mutableFloatStateOf(0.45f) }
    var brightness by remember { mutableFloatStateOf(0.72f) }
    PanelBackground(onClose = onClose, title = "Control Center") {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            ControlTile("Wi-Fi", "⌁", Modifier.weight(1f)) { openSystemPage(context, Settings.ACTION_WIFI_SETTINGS) }
            ControlTile("Bluetooth", "ᛒ", Modifier.weight(1f)) { openSystemPage(context, Settings.ACTION_BLUETOOTH_SETTINGS) }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            ControlTile("Máy bay", "✈", Modifier.weight(1f)) { openSystemPage(context, Settings.ACTION_AIRPLANE_MODE_SETTINGS) }
            ControlTile(if (torchOn) "Đèn pin: bật" else "Đèn pin", "☼", Modifier.weight(1f), active = torchOn, onClick = onTorch)
        }
        Spacer(Modifier.height(14.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .82f)), shape = RoundedCornerShape(23.dp)) {
            Column(Modifier.padding(15.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Brightness6, null, tint = Ink)
                    Text("  Độ sáng", color = Ink, fontWeight = FontWeight.SemiBold)
                }
                Slider(value = brightness, onValueChange = {
                    brightness = it
                    val activity = context.findActivity()
                    activity?.window?.let { window ->
                        val params = window.attributes
                        params.screenBrightness = it.coerceIn(.05f, 1f)
                        window.attributes = params
                    }
                })
            }
        }
        Spacer(Modifier.height(10.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .82f)), shape = RoundedCornerShape(23.dp)) {
            Column(Modifier.padding(15.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.VolumeUp, null, tint = Ink)
                    Text("  Âm lượng", color = Ink, fontWeight = FontWeight.SemiBold)
                }
                Slider(value = volume, onValueChange = {
                    volume = it
                    val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    audio.setStreamVolume(AudioManager.STREAM_MUSIC, (it * max).toInt(), 0)
                })
            }
        }
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
            Button(onClick = { openSystemPage(context, Settings.ACTION_SOUND_SETTINGS) }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE7EFFB), contentColor = Ink)) { Text("Âm thanh") }
            Button(onClick = onNotifications, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE7EFFB), contentColor = Ink)) { Text("Thông báo") }
        }
        Text("Một số công tắc được mở trong Cài đặt Android vì Android giới hạn ứng dụng bên thứ ba tự thay đổi chúng.", color = Muted, fontSize = 11.sp, lineHeight = 15.sp)
    }
}

@Composable
private fun ControlTile(label: String, symbol: String, modifier: Modifier = Modifier, active: Boolean = false, onClick: () -> Unit) {
    Surface(
        modifier = modifier.height(82.dp),
        color = if (active) Color(0xFF147DF5) else Color.White.copy(alpha = .82f),
        shape = RoundedCornerShape(22.dp),
        onClick = onClick
    ) {
        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Text(symbol, fontSize = 23.sp, color = if (active) Color.White else Ink, fontWeight = FontWeight.Bold)
            Text(label, fontSize = 12.sp, color = if (active) Color.White else Ink, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun NotificationPanel(onClose: () -> Unit) {
    val context = LocalContext.current
    PanelBackground(onClose = onClose, title = "Thông báo") {
        Button(
            onClick = { openSystemPage(context, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) },
            colors = ButtonDefaults.buttonColors(containerColor = Blue),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Cấp quyền truy cập thông báo") }
        Text("Cho phép launcher đọc thông báo để hiển thị chúng tại đây. Bạn có thể tắt quyền bất cứ lúc nào trong Cài đặt Android.", color = Muted, fontSize = 12.sp)
        if (NotificationCenter.items.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Text("Chưa có thông báo.\nThông báo mới sẽ xuất hiện ở đây sau khi bạn cấp quyền.", color = Muted, textAlign = TextAlign.Center)
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                NotificationCenter.items.take(15).forEach { item -> NotificationCard(item) }
            }
        }
    }
}

@Composable
private fun NotificationCard(item: LauncherNotification) {
    Surface(color = Color.White.copy(alpha = .88f), shape = RoundedCornerShape(19.dp), modifier = Modifier.fillMaxWidth(), onClick = {
        runCatching { item.contentIntent?.send() }
    }) {
        Column(Modifier.padding(13.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(item.appName, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(item.postedAt)), color = Muted, fontSize = 10.sp)
            }
            if (item.title.isNotBlank()) Text(item.title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            if (item.message.isNotBlank()) Text(item.message, color = Ink.copy(alpha = .85f), fontSize = 12.sp)
        }
    }
}

@Composable
private fun SettingsPanel(
    context: Context,
    showIsland: Boolean,
    animationsEnabled: Boolean,
    iconSize: Float,
    onIsland: (Boolean) -> Unit,
    onAnimations: (Boolean) -> Unit,
    onIconSize: (Float) -> Unit,
    onRefresh: () -> Unit,
    onClose: () -> Unit
) {
    PanelBackground(onClose = onClose, title = "Cài đặt Launcher") {
        SettingSwitch("Dynamic Island", "Bật đảo động mô phỏng ở đầu màn hình", showIsland, onIsland)
        Divider(color = Color(0xFFE7EBF2))
        SettingSwitch("Animation", "Dùng chuyển động khi mở bảng và đảo động", animationsEnabled, onAnimations)
        Divider(color = Color(0xFFE7EBF2))
        Column(Modifier.padding(vertical = 8.dp)) {
            Text("Kích thước biểu tượng", color = Ink, fontWeight = FontWeight.SemiBold)
            Slider(value = iconSize, onValueChange = onIconSize, valueRange = .8f..1.2f)
            Text("${(iconSize * 100).toInt()}%", color = Muted, fontSize = 11.sp)
        }
        Divider(color = Color(0xFFE7EBF2))
        SettingsAction("Đặt làm Launcher mặc định", "Chọn iOS 26 Launcher làm ứng dụng Màn hình chính", onClick = { requestHomeRole(context) })
        SettingsAction("Bật bàn phím kiểu iOS", "Mở cài đặt để bật và chọn bàn phím", onClick = { openSystemPage(context, Settings.ACTION_INPUT_METHOD_SETTINGS) })
        SettingsAction("Quyền thông báo", "Cho phép launcher hiển thị thông báo Android", onClick = { openSystemPage(context, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) })
        SettingsAction("Làm mới danh sách ứng dụng", "Tìm lại ứng dụng đã cài trên điện thoại", onClick = onRefresh)
        Text("Launcher không thay thế System UI của Android. Wi-Fi, Bluetooth, mạng di động và một số quyền hệ thống vẫn do Android quản lý.", color = Muted, fontSize = 11.sp, lineHeight = 15.sp)
    }
}

@Composable
private fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun SettingsAction(title: String, subtitle: String, onClick: () -> Unit) {
    androidx.compose.material3.TextButton(onClick = onClick, modifier = Modifier.fillMaxWidth(), contentPadding = PaddingValues(vertical = 10.dp)) {
        Column(Modifier.fillMaxWidth()) {
            Text(title, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun PanelBackground(onClose: () -> Unit, title: String, content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color(0x660A1428)).padding(top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding() + 9.dp, bottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding() + 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp).fillMaxSize(.96f),
            color = Color(0xF2F2F5FA),
            shape = RoundedCornerShape(30.dp),
            shadowElevation = 18.dp
        ) {
            Column(Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 13.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(title, color = Ink, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    IconButton(onClick = onClose) {
                        Icon(Icons.Filled.Close, "Đóng", tint = Ink)
                    }
                }
                Divider(color = Color(0xFFE2E8F0))
                Spacer(Modifier.height(12.dp))
                Column(Modifier.fillMaxSize(), content = content)
            }
        }
    }
}

private fun pickDockApps(apps: List<InstalledApp>): List<InstalledApp> {
    if (apps.isEmpty()) return emptyList()
    val hints = listOf("phone", "dialer", "message", "chrome", "camera")
    val selected = mutableListOf<InstalledApp>()
    hints.forEach { hint ->
        apps.firstOrNull { it.packageName.contains(hint, true) || it.label.contains(hint, true) }
            ?.let { if (selected.none { s -> s.packageName == it.packageName }) selected.add(it) }
    }
    apps.forEach { if (selected.size < 4 && selected.none { s -> s.packageName == it.packageName }) selected.add(it) }
    return selected.take(4)
}

private fun nowTime(): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
private fun todayDate(): String = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date()).replaceFirstChar { it.uppercase() }

private fun openSystemPage(context: Context, action: String) {
    try {
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

private fun setTorch(context: Context, enabled: Boolean): Boolean {
    return try {
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val cameraId = manager.cameraIdList.firstOrNull { id ->
            manager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return false
        manager.setTorchMode(cameraId, enabled)
        enabled
    } catch (_: Exception) {
        false
    }
}

private fun Context.findActivity(): Activity? {
    var current = this
    while (current is android.content.ContextWrapper) {
        if (current is Activity) return current
        current = current.baseContext
    }
    return current as? Activity
}

private fun requestHomeRole(context: Context) {
    if (Build.VERSION.SDK_INT >= 29) {
        val roleManager = context.getSystemService(RoleManager::class.java)
        if (roleManager?.isRoleAvailable(RoleManager.ROLE_HOME) == true && !roleManager.isRoleHeld(RoleManager.ROLE_HOME)) {
            val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            return
        }
    }
    openSystemPage(context, Settings.ACTION_HOME_SETTINGS)
}
