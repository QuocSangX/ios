package com.example.ios26launcher.keyboard

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.TextView

/** A lightweight iOS-inspired QWERTY IME. It does not collect or transmit typed text. */
class IosKeyboardService : InputMethodService() {
    private var shifted = false
    private var symbols = false
    private var activeEditorInfo: EditorInfo? = null

    override fun onCreateInputView(): View = buildKeyboard()

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        activeEditorInfo = attribute
        shifted = attribute?.let { (it.inputType and android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES) != 0 } ?: false
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    private fun buildKeyboard(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(5), dp(8), dp(5), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.rgb(210, 215, 224))
                cornerRadius = dp(18).toFloat()
            }
        }

        val rows = if (symbols) {
            listOf(
                listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0"),
                listOf("@", "#", "$", "%", "&", "-", "+", "(", ")", "/"),
                listOf("=", "*", "\"", "'", ":", ";", "!", "?", "⌫")
            )
        } else {
            listOf(
                listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p"),
                listOf("a", "s", "d", "f", "g", "h", "j", "k", "l"),
                listOf("⇧", "z", "x", "c", "v", "b", "n", "m", "⌫")
            )
        }

        rows.forEachIndexed { rowIndex, keys ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            keys.forEach { key ->
                val widthWeight = when (key) {
                    "⇧", "⌫" -> 1.35f
                    else -> 1f
                }
                row.addView(makeKey(key, widthWeight, rowIndex == 2 && (key == "⇧" || key == "⌫")))
            }
            root.addView(row, LinearLayout.LayoutParams(-1, dp(47)).apply {
                bottomMargin = dp(8)
                leftMargin = if (rowIndex == 1) dp(12) else 0
                rightMargin = if (rowIndex == 1) dp(12) else 0
            })
        }

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        bottom.addView(makeKey("123", 1.35f, true) { symbols = !symbols; setInputView(buildKeyboard()) })
        bottom.addView(makeKey(",", 0.8f, false) { currentInputConnection?.commitText(",", 1) })
        bottom.addView(makeKey("🌐", 0.9f, false) { switchToNextInputMethod(false) })
        bottom.addView(makeKey("space", 4.2f, false) { currentInputConnection?.commitText(" ", 1) })
        bottom.addView(makeKey(".", 0.8f, false) { currentInputConnection?.commitText(".", 1) })
        bottom.addView(makeKey("↵", 1.3f, true) { handleEnter() })
        root.addView(bottom, LinearLayout.LayoutParams(-1, dp(46)))
        return root
    }

    private fun makeKey(
        label: String,
        weight: Float,
        special: Boolean,
        action: (() -> Unit)? = null
    ): TextView {
        val key = TextView(this).apply {
            text = when {
                label == "space" -> "English (US)"
                label.length == 1 && !special && shifted -> label.uppercase()
                else -> label
            }
            textSize = if (label == "space") 12f else 20f
            setTextColor(Color.rgb(28, 32, 42))
            gravity = Gravity.CENTER
            typeface = if (special) Typeface.DEFAULT else Typeface.create("sans-serif", Typeface.NORMAL)
            background = GradientDrawable().apply {
                setColor(if (special) Color.rgb(174, 183, 198) else Color.WHITE)
                cornerRadius = dp(6).toFloat()
            }
            elevation = dp(1).toFloat()
            setOnClickListener {
                if (action != null) action()
                else when (label) {
                    "⇧" -> { shifted = !shifted; setInputView(buildKeyboard()) }
                    "⌫" -> currentInputConnection?.deleteSurroundingText(1, 0)
                    else -> {
                        val out = if (shifted) label.uppercase() else label
                        currentInputConnection?.commitText(out, 1)
                        shifted = false
                    }
                }
            }
        }
        return key.apply {
            layoutParams = LinearLayout.LayoutParams(0, -1, weight).apply {
                leftMargin = dp(2)
                rightMargin = dp(2)
            }
        }
    }

    private fun handleEnter() {
        val connection = currentInputConnection ?: return
        val action = activeEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_NONE
        if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            connection.performEditorAction(action)
        } else {
            connection.commitText("\n", 1)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
